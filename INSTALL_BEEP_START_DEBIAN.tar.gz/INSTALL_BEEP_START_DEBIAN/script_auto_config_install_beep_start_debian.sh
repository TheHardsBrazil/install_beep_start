#!/bin/bash

# Script principal para instalar e ativar o beep_start automaticamente

REPO_URL="https://github.com/thehardsbrazil/install_beep_start_debian"
PACKAGE_TAR="INSTALL_BEEP_START_DEBIAN.tar.gz"
PACKAGE_DIR="INSTALL_BEEP_START_DEBIAN"

echo "=== Clonando repositório... ==="
git clone $REPO_URL || { echo "Erro ao clonar repositório"; exit 1; }

cd install_beep_start_debian || { echo "Repositório não encontrado"; exit 1; }

echo "=== Extraindo pacote $PACKAGE_TAR... ==="
tar -xvzf $PACKAGE_TAR || { echo "Erro ao descompactar $PACKAGE_TAR"; exit 1; }

cd $PACKAGE_DIR || { echo "Erro ao entrar na pasta $PACKAGE_DIR"; exit 1; }

echo "=== Executando instalação do .deb... ==="
chmod +x SCRIPT_INSTALL_BEEP_START/SCRIPT_AUTO_INSTALL_BEEP_START/script_auto_install_beep_start.sh
SCRIPT_INSTALL_BEEP_START/SCRIPT_AUTO_INSTALL_BEEP_START/script_auto_install_beep_start.sh || { echo "Falha na instalação do .deb"; exit 1; }

echo "=== Configurando auto start... ==="
chmod +x ATIVAR_INICIO_AUTO_BEEP_START/SCRIPT_AUTO_ATIVAR/script_auto_start_beep_start.sh
ATIVAR_INICIO_AUTO_BEEP_START/SCRIPT_AUTO_ATIVAR/script_auto_start_beep_start.sh || { echo "Falha ao configurar auto start"; exit 1; }

echo "=== Instalação concluída com sucesso! ==="
