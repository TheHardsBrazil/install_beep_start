#!/bin/bash

# Definindo variáveis
SERVICE_NAME="beep_start"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
EXECUTABLE_PATH="/opt/beep_start/beep_start"
USER="agrovendas"
WORKING_DIR="/opt/beep_start"
DISPLAY_ENV="DISPLAY=:0"

# Criar o arquivo de serviço
echo "Criando o arquivo de serviço ${SERVICE_FILE}..."
cat <<EOL | sudo tee $SERVICE_FILE
[Unit]
Description=Serviço Beep Start

[Service]
ExecStart=${EXECUTABLE_PATH}
Restart=always
User=${USER}
WorkingDirectory=${WORKING_DIR}
Environment="${DISPLAY_ENV}"

[Install]
WantedBy=multi-user.target
EOL

# Recarregar o systemd
echo "Recarregando o systemd..."
sudo systemctl daemon-reload

# Habilitar o serviço para iniciar no boot
echo "Habilitando o serviço ${SERVICE_NAME}..."
sudo systemctl enable $SERVICE_NAME

# Iniciar o serviço
echo "Iniciando o serviço ${SERVICE_NAME}..."
sudo systemctl start $SERVICE_NAME

# Verificar o status do serviço
echo "Verificando o status do serviço ${SERVICE_NAME}..."
sudo systemctl status $SERVICE_NAME
