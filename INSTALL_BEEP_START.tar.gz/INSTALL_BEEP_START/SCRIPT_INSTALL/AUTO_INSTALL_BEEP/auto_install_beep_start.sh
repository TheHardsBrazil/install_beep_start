#!/bin/bash

# Definindo variáveis
INSTALL_DIR="/home/agrovendas/INSTALL_BEEP_START"
DEB_PACKAGE="beepstart_linux_amd64.deb"

# Navegar até o diretório de instalação
echo "Navegando até o diretório ${INSTALL_DIR}..."
cd $INSTALL_DIR || { echo "Diretório não encontrado!"; exit 1; }

# Verificar se o arquivo .deb existe
if [ ! -f "$DEB_PACKAGE" ]; then
    echo "Arquivo ${DEB_PACKAGE} não encontrado no diretório ${INSTALL_DIR}."
    exit 1
fi

# Instalar o pacote .deb
echo "Instalando o pacote ${DEB_PACKAGE}..."
sudo dpkg -i "$DEB_PACKAGE"

# Resolver dependências, se necessário
echo "Resolvendo dependências..."
sudo apt-get install -f

# Verificar se a instalação foi bem-sucedida
if [ $? -eq 0 ]; then
    echo "Instalação do beep_start concluída com sucesso!"
else
    echo "Houve um erro durante a instalação do beep_start."
    exit 1
fi
