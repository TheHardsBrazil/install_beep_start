#!/bin/bash

# Definindo variáveis
DEB_FILE="beepstart_linux_amd64.deb"

# Instalar o pacote .deb
echo "Instalando o pacote ${DEB_FILE}..."
sudo dpkg -i $DEB_FILE

# Resolver dependências, se necessário
echo "Resolvendo dependências..."
sudo apt-get install -f

# Verificar se a instalação foi bem-sucedida
if [ $? -eq 0 ]; then
    echo "Instalação do ${DEB_FILE} concluída com sucesso."
else
    echo "Erro na instalação do ${DEB_FILE}. Verifique os logs."
fi





